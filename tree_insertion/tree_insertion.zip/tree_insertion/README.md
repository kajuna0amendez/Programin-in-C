# Binary Search Tree Insertion

1) cd into the root of the project
2) run "export LD_LIBRARY_PATH=lib:$LD_LIBRARY_PATH" you need that for the linkage
2) Take a look at the Makefile 

## make all the libraries 
make all

## clean all 
make clean

## build main
make build

## Run Main 
./bin/main
